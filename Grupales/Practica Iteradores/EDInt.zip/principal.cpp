#include <vector>
#include <iostream>
#include <map>
#include "diccionario.h"

using namespace std;

int main(){

vector<diccionario<string,int> > V;

diccionario<string,int> aux("Hola",2);

V.push_back(aux);

cout << V.begin()<<endl;
cout << (*V.begin()).second<<endl;

p_e = &V[0]; // tomamos la direccion del primer elemento del vector
cout << (*p_e).first << (*p_e).second<< endl;
(*p_e).first = "XXXX"; //Correcto

p_vt = (pair<const string,int> *) &V[0];
cout << (*p_vt).first << (*p_vt).second<< endl;
(*p_vt).second = 234;
cout << (*p_vt).first << (*p_vt).second<< endl;
//(*p_vt).first = "XXXX"; //INCORRECTO
}
