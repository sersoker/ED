#include "diccionario.h"
#include <iostream>

using namespace std;
 

void load(diccionario & d, const string & s){
 // lectura del fichero en el diccionario
}
int main()
{
    diccionario D;
    meteorito m;
    defM x;
 
    

    D.insert(m);
    pair<diccionario::entrada,bool> p;
    p = D.find("aaaa");
    if (p.second==true) cout << p.first << endl;
    else cout << "No existe aaaa" << endl;

    cout<< D["Barcelona"] << endl;

    D["Valencia"] = x;
    cout<< D["Valencia"] << endl;

    diccionario Meteoritos;
    load(meteoritos, "meteorites_all.csv");

   return 0;
}
